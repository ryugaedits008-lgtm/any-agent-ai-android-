# Retrofit
-keepattributes Signature
-keepattributes *Annotation*
-keep class retrofit2.** { *; }
-keep interface retrofit2.** { *; }
-keepclasseswithmembers class * {
    @retrofit2.http.* <methods>;
}

# Gson
-keep class com.google.gson.** { *; }
-keep class com.anyai.agent.network.** { *; }
-keep class com.anyai.agent.data.** { *; }

# OkHttp
-dontwarn okhttp3.**
-dontwarn okio.**

# libsu
-keep class com.topjohnwu.superuser.** { *; }
