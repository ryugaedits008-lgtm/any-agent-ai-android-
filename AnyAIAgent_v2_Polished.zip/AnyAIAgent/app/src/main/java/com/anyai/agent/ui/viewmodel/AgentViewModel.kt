package com.anyai.agent.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.anyai.agent.data.AppDatabase
import com.anyai.agent.data.KeyManager
import com.anyai.agent.data.TaskLog
import com.anyai.agent.data.LogType
import com.anyai.agent.engine.ActionEngine
import com.anyai.agent.network.AiClient
import com.anyai.agent.network.ChatRequest
import com.anyai.agent.network.Message
import com.anyai.agent.service.AnyAccessibilityService
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class UiLog(val message: String, val type: LogType)

class AgentViewModel(application: Application) : AndroidViewModel(application) {

    private val db = AppDatabase.getDatabase(application)
    private val keyManager = KeyManager(application)
    private val actionEngine = ActionEngine(application)

    val apiConfigs = db.apiConfigDao().getAllConfigs()
    val taskLogs = db.taskLogDao().getAllLogs()

    private val _uiLogs = MutableStateFlow<List<UiLog>>(emptyList())
    val uiLogs: StateFlow<List<UiLog>> = _uiLogs.asStateFlow()

    private val _isRunning = MutableStateFlow(false)
    val isRunning: StateFlow<Boolean> = _isRunning.asStateFlow()

    val isRooted: Boolean get() = actionEngine.isRooted()
    val isAccessibilityRunning: StateFlow<Boolean> = AnyAccessibilityService.isRunning

    private fun addLog(message: String, type: LogType) {
        _uiLogs.value = _uiLogs.value + UiLog(message, type)
        viewModelScope.launch {
            db.taskLogDao().insertLog(TaskLog(message = message, type = type))
        }
    }

    fun runTask(userTask: String) {
        if (_isRunning.value) return

        viewModelScope.launch {
            _isRunning.value = true
            addLog("Task: $userTask", LogType.USER)

            val activeConfig = db.apiConfigDao().getActiveConfig()
            if (activeConfig == null) {
                addLog("Error: No active API configured. Go to APIs tab and add one.", LogType.ERROR)
                _isRunning.value = false
                return@launch
            }

            val apiKey = keyManager.getApiKey(activeConfig.id.toString())
            if (apiKey.isNullOrEmpty()) {
                addLog("Error: API key missing for ${activeConfig.providerName}", LogType.ERROR)
                _isRunning.value = false
                return@launch
            }

            if (!AnyAccessibilityService.isRunning.value) {
                addLog("Warning: Accessibility Service is not running. Some actions won't work.", LogType.ERROR)
            }

            val aiService = AiClient.create(activeConfig.endpointUrl)
            val tools = AiClient.getAgentTools()
            val systemPrompt = buildSystemPrompt()

            val conversationHistory = mutableListOf(
                Message(role = "system", content = systemPrompt),
                Message(role = "user", content = userTask)
            )

            addLog("Using: ${activeConfig.providerName} / ${activeConfig.modelName}", LogType.INFO)

            // Agentic loop - max 15 steps
            var stepCount = 0
            var taskDone = false

            while (stepCount < 15 && !taskDone) {
                stepCount++
                addLog("Step $stepCount: Thinking...", LogType.INFO)

                try {
                    val response = aiService.getCompletion(
                        url = "${activeConfig.endpointUrl.trimEnd('/')}/chat/completions",
                        auth = "Bearer $apiKey",
                        request = ChatRequest(
                            model = activeConfig.modelName,
                            messages = conversationHistory,
                            tools = tools
                        )
                    )

                    if (response.error != null) {
                        addLog("API Error: ${response.error.message}", LogType.ERROR)
                        break
                    }

                    val choice = response.choices?.firstOrNull()
                    if (choice == null) {
                        addLog("Error: Empty response from AI", LogType.ERROR)
                        break
                    }

                    val assistantMessage = choice.message
                    conversationHistory.add(assistantMessage)

                    // If AI just sends text (no tool call)
                    if (assistantMessage.toolCalls.isNullOrEmpty()) {
                        val text = assistantMessage.content ?: "(no response)"
                        addLog("AI: $text", LogType.AI_RESPONSE)
                        taskDone = true
                        break
                    }

                    // Execute each tool call
                    for (toolCall in assistantMessage.toolCalls) {
                        val fnName = toolCall.function.name
                        val fnArgs = AiClient.parseArguments(toolCall.function.arguments)

                        addLog("▶ $fnName(${toolCall.function.arguments})", LogType.ACTION)

                        val result = actionEngine.executeAction(fnName, fnArgs)
                        addLog("  ↳ $result", LogType.INFO)

                        if (fnName == "task_complete") {
                            taskDone = true
                        }

                        // Feed result back to AI
                        conversationHistory.add(
                            Message(
                                role = "tool",
                                content = result,
                                toolCallId = toolCall.id,
                                name = fnName
                            )
                        )
                    }

                } catch (e: Exception) {
                    addLog("Error: ${e.message}", LogType.ERROR)
                    break
                }
            }

            if (stepCount >= 15 && !taskDone) {
                addLog("Stopped: max steps (15) reached", LogType.ERROR)
            } else if (taskDone) {
                addLog("✓ Task completed", LogType.INFO)
            }

            _isRunning.value = false
        }
    }

    fun clearLogs() {
        viewModelScope.launch {
            db.taskLogDao().clearLogs()
            _uiLogs.value = emptyList()
        }
    }

    private fun buildSystemPrompt(): String {
        val rootStatus = if (actionEngine.isRooted()) "ROOTED (all tools available)" else "NON-ROOTED (no shell commands)"
        val accessStatus = if (AnyAccessibilityService.isRunning.value) "ACTIVE" else "INACTIVE"
        return """
You are an Android phone agent. You control the user's phone to complete tasks.

Device status:
- Root: $rootStatus
- Accessibility Service: $accessStatus

Instructions:
1. Always call read_screen first to understand what is currently on screen
2. Plan your steps based on what you see
3. Execute actions one at a time
4. After tapping, wait briefly then read_screen again to confirm the result
5. If something fails, try an alternative approach
6. Call task_complete when done
7. Be precise with coordinates from the screen tree
8. Never guess - always read the screen before acting
        """.trimIndent()
    }
}
