package com.anyai.agent.ui.screens

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.anyai.agent.data.LogType
import com.anyai.agent.ui.theme.AnyAIColors
import com.anyai.agent.ui.viewmodel.AgentViewModel
import com.anyai.agent.ui.viewmodel.UiLog

@Composable
fun HomeScreen(vm: AgentViewModel = viewModel()) {
    var taskInput by remember { mutableStateOf("") }
    val uiLogs by vm.uiLogs.collectAsState()
    val isRunning by vm.isRunning.collectAsState()
    val isAccessibilityOn by vm.isAccessibilityRunning.collectAsState()
    val listState = rememberLazyListState()

    LaunchedEffect(uiLogs.size) {
        if (uiLogs.isNotEmpty()) listState.animateScrollToItem(uiLogs.size - 1)
    }

    Box(modifier = Modifier.fillMaxSize().background(AnyAIColors.Background)) {

        // Subtle top gradient
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(200.dp)
                .drawBehind {
                    drawCircle(
                        brush = Brush.radialGradient(
                            colors = listOf(AnyAIColors.Neon.copy(alpha = 0.08f), Color.Transparent),
                            center = Offset(size.width * 0.5f, 0f),
                            radius = size.width * 0.8f
                        )
                    )
                }
        )

        Column(modifier = Modifier.fillMaxSize()) {

            // ── Header ──────────────────────────────────────
            Column(modifier = Modifier.padding(horizontal = 20.dp, vertical = 16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            "AnyAI Agent",
                            fontSize = 26.sp,
                            fontWeight = FontWeight.Black,
                            color = AnyAIColors.TextPrimary
                        )
                        Text(
                            "Your phone, AI-powered",
                            fontSize = 12.sp,
                            color = AnyAIColors.TextMuted
                        )
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        MiniChip(
                            text = if (vm.isRooted) "ROOT" else "STD",
                            color = if (vm.isRooted) AnyAIColors.GreenOk else AnyAIColors.Neon
                        )
                        MiniChip(
                            text = if (isAccessibilityOn) "A11Y ●" else "A11Y ○",
                            color = if (isAccessibilityOn) AnyAIColors.GreenOk else AnyAIColors.RedError
                        )
                    }
                }

                // Warning banner
                AnimatedVisibility(visible = !isAccessibilityOn) {
                    Surface(
                        modifier = Modifier.fillMaxWidth().padding(top = 10.dp),
                        color = AnyAIColors.YellowWarn.copy(alpha = 0.1f),
                        shape = RoundedCornerShape(10.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, AnyAIColors.YellowWarn.copy(alpha = 0.3f))
                    ) {
                        Text(
                            "⚠  Enable Accessibility Service → Perms tab",
                            modifier = Modifier.padding(10.dp),
                            fontSize = 12.sp,
                            color = AnyAIColors.YellowWarn
                        )
                    }
                }
            }

            // ── Chat log ────────────────────────────────────
            Box(modifier = Modifier.weight(1f)) {
                if (uiLogs.isEmpty()) {
                    EmptyState(modifier = Modifier.fillMaxSize())
                } else {
                    LazyColumn(
                        state = listState,
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        items(uiLogs) { log -> ChatBubble(log) }

                        if (isRunning) {
                            item { ThinkingIndicator() }
                        }
                    }
                }
            }

            // ── Input row ───────────────────────────────────
            Surface(
                color = AnyAIColors.Surface,
                tonalElevation = 0.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .padding(horizontal = 16.dp, vertical = 12.dp)
                        .navigationBarsPadding(),
                    verticalAlignment = Alignment.Bottom,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedTextField(
                        value = taskInput,
                        onValueChange = { taskInput = it },
                        modifier = Modifier.weight(1f),
                        placeholder = {
                            Text(
                                "Give AI a task…",
                                color = AnyAIColors.TextMuted,
                                fontSize = 14.sp
                            )
                        },
                        enabled = !isRunning,
                        maxLines = 4,
                        shape = RoundedCornerShape(16.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = AnyAIColors.Neon,
                            unfocusedBorderColor = AnyAIColors.Border,
                            focusedContainerColor = AnyAIColors.SurfaceCard,
                            unfocusedContainerColor = AnyAIColors.SurfaceCard,
                            cursorColor = AnyAIColors.Neon,
                            focusedTextColor = AnyAIColors.TextPrimary,
                            unfocusedTextColor = AnyAIColors.TextPrimary,
                        ),
                        textStyle = LocalTextStyle.current.copy(fontSize = 14.sp)
                    )

                    // Send button
                    val btnColor by animateColorAsState(
                        targetValue = if (isRunning || taskInput.isBlank()) AnyAIColors.SurfaceBright else AnyAIColors.Neon,
                        label = "btnColor"
                    )
                    Box(
                        modifier = Modifier
                            .size(52.dp)
                            .clip(RoundedCornerShape(14.dp))
                            .background(btnColor)
                            .then(
                                if (!isRunning && taskInput.isNotBlank())
                                    Modifier.drawBehind {
                                        drawCircle(
                                            brush = Brush.radialGradient(
                                                colors = listOf(AnyAIColors.Neon.copy(alpha = 0.4f), Color.Transparent)
                                            )
                                        )
                                    }
                                else Modifier
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        IconButton(
                            onClick = {
                                if (taskInput.isNotBlank() && !isRunning) {
                                    vm.runTask(taskInput.trim())
                                    taskInput = ""
                                }
                            },
                            enabled = !isRunning && taskInput.isNotBlank()
                        ) {
                            if (isRunning) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(20.dp),
                                    strokeWidth = 2.dp,
                                    color = AnyAIColors.Neon
                                )
                            } else {
                                Icon(
                                    Icons.Default.Send,
                                    contentDescription = "Run",
                                    tint = if (taskInput.isNotBlank()) Color.White else AnyAIColors.TextMuted,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ChatBubble(log: UiLog) {
    val isUser = log.type == LogType.USER
    val isError = log.type == LogType.ERROR

    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start
    ) {
        if (!isUser) {
            // AI avatar dot
            Box(
                modifier = Modifier
                    .padding(end = 8.dp, top = 4.dp)
                    .size(28.dp)
                    .clip(CircleShape)
                    .background(
                        when (log.type) {
                            LogType.ACTION      -> AnyAIColors.YellowWarn.copy(alpha = 0.2f)
                            LogType.AI_RESPONSE -> AnyAIColors.Neon.copy(alpha = 0.2f)
                            LogType.ERROR       -> AnyAIColors.RedError.copy(alpha = 0.2f)
                            else                -> AnyAIColors.SurfaceBright
                        }
                    ),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    when (log.type) {
                        LogType.ACTION      -> "▶"
                        LogType.AI_RESPONSE -> "AI"
                        LogType.ERROR       -> "!"
                        else                -> "·"
                    },
                    fontSize = if (log.type == LogType.AI_RESPONSE) 8.sp else 11.sp,
                    color = when (log.type) {
                        LogType.ACTION      -> AnyAIColors.YellowWarn
                        LogType.AI_RESPONSE -> AnyAIColors.Neon
                        LogType.ERROR       -> AnyAIColors.RedError
                        else                -> AnyAIColors.TextMuted
                    },
                    fontWeight = FontWeight.Bold
                )
            }
        }

        Surface(
            color = when {
                isUser  -> AnyAIColors.Neon.copy(alpha = 0.15f)
                isError -> AnyAIColors.RedError.copy(alpha = 0.1f)
                log.type == LogType.ACTION -> AnyAIColors.YellowWarn.copy(alpha = 0.08f)
                log.type == LogType.AI_RESPONSE -> AnyAIColors.SurfaceCard
                else    -> AnyAIColors.Surface
            },
            shape = RoundedCornerShape(
                topStart = if (isUser) 16.dp else 4.dp,
                topEnd = if (isUser) 4.dp else 16.dp,
                bottomStart = 16.dp,
                bottomEnd = 16.dp
            ),
            border = if (isUser) androidx.compose.foundation.BorderStroke(1.dp, AnyAIColors.Neon.copy(alpha = 0.3f)) else null,
            modifier = Modifier.widthIn(max = 300.dp)
        ) {
            Text(
                text = log.message,
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                fontSize = if (log.type == LogType.ACTION || log.type == LogType.INFO) 11.sp else 13.sp,
                fontFamily = if (log.type == LogType.ACTION) FontFamily.Monospace else FontFamily.Default,
                color = when {
                    isUser  -> AnyAIColors.TextPrimary
                    isError -> AnyAIColors.RedError
                    log.type == LogType.ACTION -> AnyAIColors.YellowWarn
                    log.type == LogType.AI_RESPONSE -> AnyAIColors.TextPrimary
                    else    -> AnyAIColors.TextSecondary
                },
                lineHeight = 18.sp
            )
        }
    }
}

@Composable
fun ThinkingIndicator() {
    val infiniteTransition = rememberInfiniteTransition(label = "dots")
    Row(
        horizontalArrangement = Arrangement.Start,
        modifier = Modifier.fillMaxWidth()
    ) {
        Surface(
            color = AnyAIColors.SurfaceCard,
            shape = RoundedCornerShape(topStart = 4.dp, topEnd = 16.dp, bottomStart = 16.dp, bottomEnd = 16.dp)
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                repeat(3) { i ->
                    val alpha by infiniteTransition.animateFloat(
                        initialValue = 0.2f, targetValue = 1f,
                        animationSpec = infiniteRepeatable(
                            tween(600, delayMillis = i * 150, easing = EaseInOutSine),
                            RepeatMode.Reverse
                        ),
                        label = "dot$i"
                    )
                    Box(
                        modifier = Modifier
                            .size(6.dp)
                            .clip(CircleShape)
                            .background(AnyAIColors.Neon.copy(alpha = alpha))
                    )
                }
            }
        }
    }
}

@Composable
fun EmptyState(modifier: Modifier = Modifier) {
    Column(
        modifier = modifier,
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text("🤖", fontSize = 48.sp)
        Spacer(modifier = Modifier.height(16.dp))
        Text("Ready for your command", fontSize = 16.sp, fontWeight = FontWeight.SemiBold, color = AnyAIColors.TextPrimary)
        Spacer(modifier = Modifier.height(8.dp))
        Text("Try:", fontSize = 12.sp, color = AnyAIColors.TextMuted)
        Spacer(modifier = Modifier.height(12.dp))
        listOf(
            "Open WhatsApp and send 'Hello' to Rahul",
            "Turn on Dark Mode in Settings",
            "Set alarm for 7 AM"
        ).forEach { example ->
            Surface(
                color = AnyAIColors.SurfaceCard,
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.padding(vertical = 3.dp)
            ) {
                Text(
                    "\"$example\"",
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
                    fontSize = 12.sp,
                    color = AnyAIColors.TextSecondary,
                    textAlign = TextAlign.Center
                )
            }
        }
    }
}

@Composable
fun MiniChip(text: String, color: Color) {
    Surface(
        color = color.copy(alpha = 0.12f),
        shape = RoundedCornerShape(6.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, color.copy(alpha = 0.3f))
    ) {
        Text(
            text,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
            fontSize = 9.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 0.8.sp,
            color = color
        )
    }
}
