package com.anyai.agent.ui

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.*
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.anyai.agent.ui.screens.*
import com.anyai.agent.ui.theme.AnyAIColors
import com.anyai.agent.ui.theme.AnyAITheme
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.outlined.Api

data class BottomNavItem(val route: String, val label: String, val icon: ImageVector)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            AnyAITheme {
                val prefs = getSharedPreferences("anyai_prefs", Context.MODE_PRIVATE)
                var onboardingDone by remember {
                    mutableStateOf(prefs.getBoolean("onboarding_done", false))
                }

                AnimatedContent(
                    targetState = onboardingDone,
                    transitionSpec = {
                        fadeIn(tween(500)) togetherWith fadeOut(tween(300))
                    },
                    label = "root"
                ) { done ->
                    if (!done) {
                        OnboardingScreen(onFinish = {
                            prefs.edit().putBoolean("onboarding_done", true).apply()
                            onboardingDone = true
                        })
                    } else {
                        MainScreen()
                    }
                }
            }
        }
    }
}

@Composable
fun MainScreen() {
    val navController = rememberNavController()
    val navBackStack by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStack?.destination?.route ?: "home"

    val navItems = listOf(
        BottomNavItem("home",        "Agent",   Icons.Default.Home),
        BottomNavItem("apis",        "APIs",    Icons.Outlined.Api),
        BottomNavItem("permissions", "Perms",   Icons.Default.Lock),
        BottomNavItem("settings",    "Settings",Icons.Default.Settings),
    )

    Scaffold(
        containerColor = AnyAIColors.Background,
        bottomBar = {
            Surface(
                color = AnyAIColors.Surface,
                tonalElevation = 0.dp,
                shadowElevation = 0.dp
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .navigationBarsPadding()
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.SpaceAround
                ) {
                    navItems.forEach { item ->
                        val selected = currentRoute == item.route
                        NavPill(
                            item = item,
                            selected = selected,
                            onClick = {
                                navController.navigate(item.route) {
                                    popUpTo("home") { saveState = true }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            }
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = "home",
            modifier = Modifier.padding(innerPadding),
            enterTransition = { fadeIn(tween(200)) },
            exitTransition = { fadeOut(tween(150)) }
        ) {
            composable("home")        { HomeScreen() }
            composable("apis")        { ApiManagerScreen() }
            composable("permissions") { PermissionsScreen() }
            composable("settings")    { SettingsScreen() }
        }
    }
}

@Composable
fun NavPill(item: BottomNavItem, selected: Boolean, onClick: () -> Unit) {
    val bgColor by animateColorAsState(
        targetValue = if (selected) AnyAIColors.Neon.copy(alpha = 0.15f) else Color.Transparent,
        animationSpec = tween(250),
        label = "navBg"
    )
    val contentColor by animateColorAsState(
        targetValue = if (selected) AnyAIColors.Neon else AnyAIColors.TextMuted,
        animationSpec = tween(250),
        label = "navContent"
    )

    Surface(
        onClick = onClick,
        color = bgColor,
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier.clip(RoundedCornerShape(12.dp))
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
            horizontalAlignment = androidx.compose.ui.Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(2.dp)
        ) {
            Icon(
                item.icon,
                contentDescription = item.label,
                tint = contentColor,
                modifier = Modifier.size(20.dp)
            )
            Text(
                item.label,
                fontSize = 10.sp,
                fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
                color = contentColor,
                letterSpacing = 0.3.sp
            )
        }
    }
}
