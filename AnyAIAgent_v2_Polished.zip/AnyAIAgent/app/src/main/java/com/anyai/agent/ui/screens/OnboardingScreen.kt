package com.anyai.agent.ui.screens

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.anyai.agent.ui.theme.AnyAIColors
import kotlinx.coroutines.delay

data class OnboardPage(
    val emoji: String,
    val title: String,
    val subtitle: String,
    val accentColor: Color,
    val description: String
)

private val PAGES = listOf(
    OnboardPage(
        emoji = "🧠",
        title = "Your AI,\nYour Rules",
        subtitle = "Bring Your Own Key",
        accentColor = AnyAIColors.Neon,
        description = "Connect any AI — Groq, Gemini, OpenAI, Claude, or your local model. No subscriptions, no lock-in."
    ),
    OnboardPage(
        emoji = "📱",
        title = "AI Controls\nYour Phone",
        subtitle = "No Screenshots Every Second",
        accentColor = AnyAIColors.NeonCyan,
        description = "The AI reads your screen intelligently using Accessibility — lightning fast, battery friendly, completely private."
    ),
    OnboardPage(
        emoji = "🔒",
        title = "Zero Data\nLeaks. Ever.",
        subtitle = "Privacy First",
        accentColor = AnyAIColors.GreenOk,
        description = "No login. No server. API keys encrypted with AES-256 and stored only on your device. Your data stays yours."
    )
)

@Composable
fun OnboardingScreen(onFinish: () -> Unit) {
    var currentPage by remember { mutableStateOf(0) }
    val page = PAGES[currentPage]

    // Pulse animation for emoji
    val pulse = rememberInfiniteTransition(label = "pulse")
    val pulseScale by pulse.animateFloat(
        initialValue = 1f, targetValue = 1.08f,
        animationSpec = infiniteRepeatable(tween(1200, easing = EaseInOutSine), RepeatMode.Reverse),
        label = "scale"
    )

    // Glow animation
    val glowAlpha by pulse.animateFloat(
        initialValue = 0.3f, targetValue = 0.7f,
        animationSpec = infiniteRepeatable(tween(1500, easing = EaseInOutSine), RepeatMode.Reverse),
        label = "glow"
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(AnyAIColors.Background)
    ) {
        // Background gradient blob
        Box(
            modifier = Modifier
                .fillMaxSize()
                .drawBehind {
                    drawCircle(
                        brush = Brush.radialGradient(
                            colors = listOf(page.accentColor.copy(alpha = glowAlpha * 0.15f), Color.Transparent),
                            center = Offset(size.width * 0.5f, size.height * 0.3f),
                            radius = size.width * 0.8f
                        )
                    )
                }
        )

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(32.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Top — logo mark
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.padding(top = 16.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .clip(CircleShape)
                        .background(page.accentColor)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    "ANYAI AGENT",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 3.sp,
                    color = AnyAIColors.TextMuted
                )
            }

            // Center — main content
            AnimatedContent(
                targetState = currentPage,
                transitionSpec = {
                    fadeIn(tween(400)) + slideInHorizontally { it / 3 } togetherWith
                            fadeOut(tween(300)) + slideOutHorizontally { -it / 3 }
                },
                label = "page"
            ) { pageIdx ->
                val pg = PAGES[pageIdx]
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(24.dp)
                ) {
                    // Emoji in glowing circle
                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier
                            .size(140.dp)
                            .scale(pulseScale)
                            .drawBehind {
                                drawCircle(
                                    brush = Brush.radialGradient(
                                        colors = listOf(pg.accentColor.copy(alpha = glowAlpha * 0.4f), Color.Transparent)
                                    )
                                )
                            }
                            .clip(CircleShape)
                            .background(pg.accentColor.copy(alpha = 0.1f))
                    ) {
                        Text(pg.emoji, fontSize = 56.sp)
                    }

                    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        // Accent pill
                        Surface(
                            color = pg.accentColor.copy(alpha = 0.15f),
                            shape = RoundedCornerShape(20.dp)
                        ) {
                            Text(
                                pg.subtitle.uppercase(),
                                modifier = Modifier.padding(horizontal = 14.dp, vertical = 5.dp),
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.5.sp,
                                color = pg.accentColor
                            )
                        }

                        Text(
                            pg.title,
                            fontSize = 36.sp,
                            fontWeight = FontWeight.Black,
                            lineHeight = 40.sp,
                            textAlign = TextAlign.Center,
                            color = AnyAIColors.TextPrimary
                        )

                        Text(
                            pg.description,
                            fontSize = 15.sp,
                            textAlign = TextAlign.Center,
                            color = AnyAIColors.TextSecondary,
                            lineHeight = 22.sp,
                            modifier = Modifier.padding(horizontal = 8.dp)
                        )
                    }
                }
            }

            // Bottom — dots + button
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(28.dp)
            ) {
                // Page dots
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    PAGES.indices.forEach { idx ->
                        val isActive = idx == currentPage
                        val width by animateDpAsState(
                            targetValue = if (isActive) 24.dp else 8.dp,
                            animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy),
                            label = "dot"
                        )
                        Box(
                            modifier = Modifier
                                .height(8.dp)
                                .width(width)
                                .clip(CircleShape)
                                .background(if (isActive) page.accentColor else AnyAIColors.Border)
                        )
                    }
                }

                // CTA Button
                Button(
                    onClick = {
                        if (currentPage < PAGES.size - 1) currentPage++
                        else onFinish()
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(56.dp),
                    shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = page.accentColor
                    )
                ) {
                    Text(
                        if (currentPage < PAGES.size - 1) "Continue →" else "Get Started",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (page.accentColor == AnyAIColors.NeonCyan) Color(0xFF050510) else Color.White
                    )
                }

                if (currentPage < PAGES.size - 1) {
                    TextButton(onClick = onFinish) {
                        Text("Skip", color = AnyAIColors.TextMuted, fontSize = 13.sp)
                    }
                } else {
                    Spacer(modifier = Modifier.height(36.dp))
                }
            }
        }
    }
}
