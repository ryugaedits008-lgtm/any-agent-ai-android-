package com.anyai.agent.data

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface ApiConfigDao {
    @Query("SELECT * FROM api_configs ORDER BY id DESC")
    fun getAllConfigs(): Flow<List<ApiConfig>>

    @Query("SELECT * FROM api_configs WHERE isActive = 1 LIMIT 1")
    suspend fun getActiveConfig(): ApiConfig?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertConfig(config: ApiConfig): Long

    @Update
    suspend fun updateConfig(config: ApiConfig)

    @Delete
    suspend fun deleteConfig(config: ApiConfig)

    @Query("UPDATE api_configs SET isActive = 0")
    suspend fun deactivateAll()

    @Query("UPDATE api_configs SET isActive = 1 WHERE id = :configId")
    suspend fun activateConfig(configId: Int)

    @Transaction
    suspend fun setActiveConfig(configId: Int) {
        deactivateAll()
        activateConfig(configId)
    }
}

@Dao
interface TaskLogDao {
    @Query("SELECT * FROM task_logs ORDER BY timestamp DESC LIMIT 200")
    fun getAllLogs(): Flow<List<TaskLog>>

    @Insert
    suspend fun insertLog(log: TaskLog)

    @Query("DELETE FROM task_logs")
    suspend fun clearLogs()
}

@Database(entities = [ApiConfig::class, TaskLog::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun apiConfigDao(): ApiConfigDao
    abstract fun taskLogDao(): TaskLogDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "anyai_database"
                ).build()
                INSTANCE = instance
                instance
            }
        }
    }
}
