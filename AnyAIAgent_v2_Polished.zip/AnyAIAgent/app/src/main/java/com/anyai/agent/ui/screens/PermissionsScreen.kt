package com.anyai.agent.ui.screens

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.core.content.PermissionChecker
import com.anyai.agent.service.AnyAccessibilityService
import com.anyai.agent.ui.theme.AnyAIColors

private data class PermItem(
    val emoji: String,
    val name: String,
    val description: String,
    val androidPermission: String?,
    val isSpecial: Boolean = false,
    val specialAction: String? = null,
    val rootOnly: Boolean = false
)

private val PERM_LIST = listOf(
    PermItem("⚙️", "Accessibility Service",
        "AI reads UI & controls screen — core feature",
        null, isSpecial = true, specialAction = Settings.ACTION_ACCESSIBILITY_SETTINGS),
    PermItem("👤", "Contacts",
        "Read contact names for tasks like 'message Rahul'",
        Manifest.permission.READ_CONTACTS),
    PermItem("💬", "SMS",
        "Read & send text messages",
        Manifest.permission.READ_SMS),
    PermItem("📞", "Call Logs",
        "Read recent call history",
        Manifest.permission.READ_CALL_LOG),
    PermItem("📷", "Camera",
        "Take photos or scan documents",
        Manifest.permission.CAMERA),
    PermItem("🎙️", "Microphone",
        "Record voice for transcription tasks",
        Manifest.permission.RECORD_AUDIO),
    PermItem("📍", "Location",
        "Find nearby places or share location",
        Manifest.permission.ACCESS_FINE_LOCATION),
    PermItem("📁", "Storage",
        "Read and write files",
        Manifest.permission.READ_MEDIA_IMAGES),
    PermItem("🐚", "Shell Commands",
        "Run system commands (Root only)",
        null, rootOnly = true),
)

@Composable
fun PermissionsScreen() {
    Box(modifier = Modifier.fillMaxSize().background(AnyAIColors.Background)) {
        Column(modifier = Modifier.fillMaxSize().padding(horizontal = 20.dp)) {
            // Header
            Column(modifier = Modifier.padding(top = 20.dp, bottom = 16.dp)) {
                Text("Permissions", fontSize = 26.sp, fontWeight = FontWeight.Black, color = AnyAIColors.TextPrimary)
                Text("Grant only what you need · revoke anytime", fontSize = 12.sp, color = AnyAIColors.TextMuted)
            }

            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                PERM_LIST.forEach { perm -> PermCard(perm) }
                Spacer(modifier = Modifier.height(80.dp))
            }
        }
    }
}

@Composable
fun PermCard(perm: PermItem) {
    val context = LocalContext.current
    var granted by remember { mutableStateOf(false) }

    // Check grant state on compose
    LaunchedEffect(perm.name) {
        granted = when {
            perm.isSpecial  -> AnyAccessibilityService.getInstance() != null
            perm.rootOnly   -> try { Runtime.getRuntime().exec("su"); true } catch (e: Exception) { false }
            perm.androidPermission != null ->
                ContextCompat.checkSelfPermission(context, perm.androidPermission) == PermissionChecker.PERMISSION_GRANTED
            else -> false
        }
    }

    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted = it }

    val borderColor by animateColorAsState(
        targetValue = if (granted) AnyAIColors.GreenOk.copy(alpha = 0.4f) else AnyAIColors.Border,
        animationSpec = tween(400), label = "border"
    )
    val bgColor by animateColorAsState(
        targetValue = if (granted) AnyAIColors.GreenOk.copy(alpha = 0.05f) else AnyAIColors.SurfaceCard,
        animationSpec = tween(400), label = "bg"
    )

    Surface(
        shape = RoundedCornerShape(14.dp),
        color = bgColor,
        modifier = Modifier.fillMaxWidth().border(1.dp, borderColor, RoundedCornerShape(14.dp))
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Emoji badge
            Box(
                modifier = Modifier.size(40.dp).clip(RoundedCornerShape(10.dp))
                    .background(if (granted) AnyAIColors.GreenOk.copy(0.1f) else AnyAIColors.SurfaceBright),
                contentAlignment = Alignment.Center
            ) {
                Text(perm.emoji, fontSize = 18.sp)
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(perm.name, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, color = AnyAIColors.TextPrimary)
                    if (perm.rootOnly) {
                        Surface(color = AnyAIColors.YellowWarn.copy(0.12f), shape = RoundedCornerShape(4.dp)) {
                            Text("ROOT", modifier = Modifier.padding(horizontal = 5.dp, vertical = 2.dp),
                                fontSize = 8.sp, fontWeight = FontWeight.Bold, letterSpacing = 0.8.sp, color = AnyAIColors.YellowWarn)
                        }
                    }
                }
                Text(perm.description, fontSize = 11.sp, color = AnyAIColors.TextMuted)
            }

            Spacer(modifier = Modifier.width(8.dp))

            if (perm.rootOnly) {
                // Root only — just show status
                Text(
                    if (granted) "✓" else "✗",
                    fontSize = 16.sp,
                    color = if (granted) AnyAIColors.GreenOk else AnyAIColors.RedError,
                    fontWeight = FontWeight.Bold
                )
            } else if (!granted) {
                Button(
                    onClick = {
                        when {
                            perm.isSpecial && perm.specialAction != null ->
                                context.startActivity(Intent(perm.specialAction).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                            perm.androidPermission != null ->
                                launcher.launch(perm.androidPermission)
                        }
                    },
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = AnyAIColors.Neon)
                ) {
                    Text("Grant", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            } else {
                OutlinedButton(
                    onClick = {
                        context.startActivity(
                            Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                                data = Uri.fromParts("package", context.packageName, null)
                                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            }
                        )
                    },
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, AnyAIColors.Border)
                ) {
                    Text("Revoke", fontSize = 12.sp, color = AnyAIColors.TextSecondary)
                }
            }
        }
    }
}
