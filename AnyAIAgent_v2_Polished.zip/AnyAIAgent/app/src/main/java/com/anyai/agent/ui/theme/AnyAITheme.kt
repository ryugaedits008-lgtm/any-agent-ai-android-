package com.anyai.agent.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

object AnyAIColors {
    val Background    = Color(0xFF050510)
    val Surface       = Color(0xFF0D0D1F)
    val SurfaceCard   = Color(0xFF12122A)
    val SurfaceBright = Color(0xFF1A1A35)
    val Border        = Color(0xFF2A2A4A)

    val Neon          = Color(0xFF7B61FF)
    val NeonCyan      = Color(0xFF00F5D4)
    val NeonPink      = Color(0xFFFF4D9E)

    val TextPrimary   = Color(0xFFF0EEFF)
    val TextSecondary = Color(0xFF8884AA)
    val TextMuted     = Color(0xFF44425A)

    val GreenOk       = Color(0xFF00E5A0)
    val YellowWarn    = Color(0xFFFFD166)
    val RedError      = Color(0xFFFF4D6A)

    val NeonGlow      = Color(0x337B61FF)
    val CyanGlow      = Color(0x2200F5D4)
}

private val DarkColors = darkColorScheme(
    primary            = AnyAIColors.Neon,
    onPrimary          = Color.White,
    secondary          = AnyAIColors.NeonCyan,
    onSecondary        = Color(0xFF050510),
    background         = AnyAIColors.Background,
    onBackground       = AnyAIColors.TextPrimary,
    surface            = AnyAIColors.Surface,
    onSurface          = AnyAIColors.TextPrimary,
    surfaceVariant     = AnyAIColors.SurfaceCard,
    onSurfaceVariant   = AnyAIColors.TextSecondary,
    error              = AnyAIColors.NeonPink,
    primaryContainer   = AnyAIColors.NeonGlow,
    onPrimaryContainer = AnyAIColors.TextPrimary,
    outline            = AnyAIColors.Border,
    outlineVariant     = AnyAIColors.TextMuted,
)

val AppTypography = Typography(
    displayLarge = TextStyle(fontWeight = FontWeight.Black,    fontSize = 34.sp, letterSpacing = (-1.5).sp),
    headlineMedium = TextStyle(fontWeight = FontWeight.Bold,   fontSize = 22.sp, letterSpacing = (-0.5).sp),
    titleMedium  = TextStyle(fontWeight = FontWeight.SemiBold, fontSize = 16.sp),
    titleSmall   = TextStyle(fontWeight = FontWeight.Medium,   fontSize = 14.sp),
    bodyMedium   = TextStyle(fontWeight = FontWeight.Normal,   fontSize = 14.sp),
    bodySmall    = TextStyle(fontWeight = FontWeight.Normal,   fontSize = 12.sp),
    labelSmall   = TextStyle(fontWeight = FontWeight.Medium,   fontSize = 10.sp, letterSpacing = 0.8.sp),
    labelMedium  = TextStyle(fontWeight = FontWeight.SemiBold, fontSize = 12.sp, letterSpacing = 0.4.sp),
)

@Composable
fun AnyAITheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = DarkColors,
        typography = AppTypography,
        content = content
    )
}
