package com.anyai.agent.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.anyai.agent.data.ApiConfig
import com.anyai.agent.data.AppDatabase
import com.anyai.agent.data.KeyManager
import kotlinx.coroutines.launch

class ApiViewModel(application: Application) : AndroidViewModel(application) {

    private val db = AppDatabase.getDatabase(application)
    private val keyManager = KeyManager(application)

    val allConfigs = db.apiConfigDao().getAllConfigs()

    fun addConfig(
        providerName: String,
        endpointUrl: String,
        apiKey: String,
        modelName: String
    ) {
        viewModelScope.launch {
            val id = db.apiConfigDao().insertConfig(
                ApiConfig(
                    providerName = providerName.trim(),
                    endpointUrl = endpointUrl.trim().trimEnd('/'),
                    apiKey = "",   // key stored separately encrypted
                    modelName = modelName.trim(),
                    isActive = false
                )
            )
            keyManager.saveApiKey(id.toString(), apiKey.trim())
        }
    }

    fun deleteConfig(config: ApiConfig) {
        viewModelScope.launch {
            keyManager.deleteApiKey(config.id.toString())
            db.apiConfigDao().deleteConfig(config)
        }
    }

    fun setActive(config: ApiConfig) {
        viewModelScope.launch {
            db.apiConfigDao().setActiveConfig(config.id)
        }
    }

    fun getApiKey(configId: Int): String {
        return keyManager.getApiKey(configId.toString()) ?: ""
    }
}
