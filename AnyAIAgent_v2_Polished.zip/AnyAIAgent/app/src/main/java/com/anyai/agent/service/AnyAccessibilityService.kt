package com.anyai.agent.service

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.graphics.Rect
import android.os.Bundle
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import org.json.JSONArray
import org.json.JSONObject

class AnyAccessibilityService : AccessibilityService() {

    companion object {
        private var instance: AnyAccessibilityService? = null
        fun getInstance(): AnyAccessibilityService? = instance

        private val _isRunning = MutableStateFlow(false)
        val isRunning: StateFlow<Boolean> = _isRunning
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        _isRunning.value = true
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {}

    override fun onDestroy() {
        super.onDestroy()
        instance = null
        _isRunning.value = false
    }

    fun getRootNode(): AccessibilityNodeInfo? = rootInActiveWindow

    // ---- Screen Reading (no screenshot needed) ----

    fun getUiTreeAsText(): String {
        val root = rootInActiveWindow ?: return "Screen: (empty)"
        val sb = StringBuilder()
        sb.appendLine("=== SCREEN UI TREE ===")
        parseNodeToText(root, sb, 0)
        return sb.toString().take(8000) // limit for AI context
    }

    private fun parseNodeToText(node: AccessibilityNodeInfo, sb: StringBuilder, depth: Int) {
        val indent = "  ".repeat(depth)
        val text = node.text?.toString()?.trim()
        val desc = node.contentDescription?.toString()?.trim()
        val cls = node.className?.toString()?.substringAfterLast(".") ?: ""
        val resId = node.viewIdResourceName?.substringAfterLast("/") ?: ""
        val bounds = Rect()
        node.getBoundsInScreen(bounds)

        val label = when {
            !text.isNullOrEmpty() -> text
            !desc.isNullOrEmpty() -> "[desc: $desc]"
            !resId.isEmpty() -> "[id: $resId]"
            else -> null
        }

        if (label != null || node.isClickable || node.isEditable) {
            sb.append(indent)
            if (node.isClickable) sb.append("[CLICKABLE] ")
            if (node.isEditable) sb.append("[INPUT] ")
            if (!cls.isEmpty()) sb.append("($cls) ")
            if (label != null) sb.append("\"$label\" ")
            sb.appendLine("@ ${bounds.centerX()},${bounds.centerY()}")
        }

        for (i in 0 until node.childCount) {
            node.getChild(i)?.let { parseNodeToText(it, sb, depth + 1) }
        }
    }

    // ---- Actions ----

    fun tap(x: Int, y: Int) {
        val path = Path().apply { moveTo(x.toFloat(), y.toFloat()) }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 100))
            .build()
        dispatchGesture(gesture, null, null)
    }

    fun tapByText(text: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val node = findNodeByText(root, text) ?: return false
        val bounds = Rect()
        node.getBoundsInScreen(bounds)
        tap(bounds.centerX(), bounds.centerY())
        return true
    }

    fun tapByResourceId(resourceId: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val nodes = root.findAccessibilityNodeInfosByViewId(resourceId)
        if (nodes.isNullOrEmpty()) return false
        val bounds = Rect()
        nodes[0].getBoundsInScreen(bounds)
        tap(bounds.centerX(), bounds.centerY())
        return true
    }

    fun typeText(text: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val focused = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
            ?: findEditableNode(root)
            ?: return false
        val args = Bundle()
        args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        return focused.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }

    fun scroll(direction: String, amount: Int = 500) {
        val display = resources.displayMetrics
        val w = display.widthPixels
        val h = display.heightPixels
        val cx = w / 2f
        val cy = h / 2f

        val (startX, startY, endX, endY) = when (direction.lowercase()) {
            "up"    -> listOf(cx, cy + amount / 2f, cx, cy - amount / 2f)
            "down"  -> listOf(cx, cy - amount / 2f, cx, cy + amount / 2f)
            "left"  -> listOf(cx + amount / 2f, cy, cx - amount / 2f, cy)
            "right" -> listOf(cx - amount / 2f, cy, cx + amount / 2f, cy)
            else    -> listOf(cx, cy + amount / 2f, cx, cy - amount / 2f)
        }

        val path = Path().apply {
            moveTo(startX, startY)
            lineTo(endX, endY)
        }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 300))
            .build()
        dispatchGesture(gesture, null, null)
    }

    fun pressKey(key: String) {
        when (key.uppercase()) {
            "BACK"    -> performGlobalAction(GLOBAL_ACTION_BACK)
            "HOME"    -> performGlobalAction(GLOBAL_ACTION_HOME)
            "RECENTS" -> performGlobalAction(GLOBAL_ACTION_RECENTS)
            "ENTER"   -> {
                val root = rootInActiveWindow ?: return
                val focused = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
                focused?.performAction(AccessibilityNodeInfo.ACTION_NEXT_AT_MOVEMENT_GRANULARITY)
            }
            "DELETE"  -> {
                val root = rootInActiveWindow ?: return
                val focused = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
                focused?.performAction(AccessibilityNodeInfo.ACTION_CUT)
            }
        }
    }

    // ---- Helpers ----

    private fun findNodeByText(node: AccessibilityNodeInfo, text: String): AccessibilityNodeInfo? {
        if (node.text?.toString()?.contains(text, ignoreCase = true) == true) return node
        if (node.contentDescription?.toString()?.contains(text, ignoreCase = true) == true) return node
        for (i in 0 until node.childCount) {
            val result = node.getChild(i)?.let { findNodeByText(it, text) }
            if (result != null) return result
        }
        return null
    }

    private fun findEditableNode(node: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        if (node.isEditable) return node
        for (i in 0 until node.childCount) {
            val result = node.getChild(i)?.let { findEditableNode(it) }
            if (result != null) return result
        }
        return null
    }
}
