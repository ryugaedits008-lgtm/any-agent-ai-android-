package com.anyai.agent.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.anyai.agent.ui.theme.AnyAIColors
import com.anyai.agent.ui.viewmodel.AgentViewModel

@Composable
fun SettingsScreen(vm: AgentViewModel = viewModel()) {
    var showClearConfirm by remember { mutableStateOf(false) }
    val isRooted = vm.isRooted

    Box(modifier = Modifier.fillMaxSize().background(AnyAIColors.Background)) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 20.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Column(modifier = Modifier.padding(top = 20.dp, bottom = 4.dp)) {
                Text("Settings", fontSize = 26.sp, fontWeight = FontWeight.Black, color = AnyAIColors.TextPrimary)
                Text("Device info & data management", fontSize = 12.sp, color = AnyAIColors.TextMuted)
            }

            // Device card
            SettingsCard(title = "Device") {
                InfoRow("Root Access", if (isRooted) "Available" else "Not Available",
                    valueColor = if (isRooted) AnyAIColors.GreenOk else AnyAIColors.TextMuted)
                InfoRow("Android", "API ${android.os.Build.VERSION.SDK_INT}")
                InfoRow("Device", "${android.os.Build.MANUFACTURER} ${android.os.Build.MODEL}")
                InfoRow("Mode", if (isRooted) "Full Control" else "Accessibility Mode")
            }

            // Privacy card
            SettingsCard(title = "Privacy") {
                listOf(
                    "No login or account required",
                    "No analytics or telemetry",
                    "API keys encrypted (AES-256)",
                    "All data stays on device",
                    "No background internet calls"
                ).forEach { item ->
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(vertical = 3.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Box(
                            modifier = Modifier.size(6.dp)
                                .clip(androidx.compose.foundation.shape.CircleShape)
                                .background(AnyAIColors.GreenOk)
                        )
                        Text(item, fontSize = 13.sp, color = AnyAIColors.TextSecondary)
                    }
                }
            }

            // Data card
            SettingsCard(title = "Data") {
                Text(
                    "Task logs are stored locally. They help you review what the AI did. Clear them anytime.",
                    fontSize = 12.sp, color = AnyAIColors.TextMuted, lineHeight = 18.sp
                )
                Spacer(modifier = Modifier.height(10.dp))
                Button(
                    onClick = { showClearConfirm = true },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = AnyAIColors.RedError.copy(alpha = 0.15f)),
                    border = androidx.compose.foundation.BorderStroke(1.dp, AnyAIColors.RedError.copy(alpha = 0.3f))
                ) {
                    Text("Clear All Logs", color = AnyAIColors.RedError, fontWeight = FontWeight.SemiBold)
                }
            }

            // About card
            SettingsCard(title = "About") {
                InfoRow("App", "AnyAI Agent")
                InfoRow("Version", "1.0.0")
                InfoRow("Build", "Kotlin + Jetpack Compose")
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    "Bring Your Own Key · No Lock-in · Privacy First",
                    fontSize = 11.sp,
                    color = AnyAIColors.Neon.copy(alpha = 0.8f),
                    letterSpacing = 0.3.sp
                )
            }

            Spacer(modifier = Modifier.height(80.dp))
        }
    }

    if (showClearConfirm) {
        AlertDialog(
            onDismissRequest = { showClearConfirm = false },
            containerColor = AnyAIColors.SurfaceCard,
            shape = RoundedCornerShape(16.dp),
            title = { Text("Clear Logs?", color = AnyAIColors.TextPrimary, fontWeight = FontWeight.Bold) },
            text = { Text("All task history will be permanently deleted.", color = AnyAIColors.TextSecondary) },
            confirmButton = {
                TextButton(onClick = { vm.clearLogs(); showClearConfirm = false }) {
                    Text("Clear", color = AnyAIColors.RedError, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showClearConfirm = false }) {
                    Text("Cancel", color = AnyAIColors.TextSecondary)
                }
            }
        )
    }
}

@Composable
fun SettingsCard(title: String, content: @Composable ColumnScope.() -> Unit) {
    Surface(
        shape = RoundedCornerShape(16.dp),
        color = AnyAIColors.SurfaceCard,
        modifier = Modifier.fillMaxWidth().border(1.dp, AnyAIColors.Border, RoundedCornerShape(16.dp))
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                title.uppercase(),
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.5.sp,
                color = AnyAIColors.TextMuted
            )
            Spacer(modifier = Modifier.height(12.dp))
            content()
        }
    }
}

@Composable
fun InfoRow(label: String, value: String, valueColor: Color = AnyAIColors.TextSecondary) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, fontSize = 13.sp, color = AnyAIColors.TextSecondary)
        Text(value, fontSize = 13.sp, color = valueColor, fontWeight = FontWeight.Medium)
    }
}
