package com.anyai.agent.data

import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

class KeyManager(context: Context) {
    private val masterKey = MasterKey.Builder(context)
        .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
        .build()

    private val sharedPreferences = EncryptedSharedPreferences.create(
        context,
        "secure_api_keys",
        masterKey,
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )

    fun saveApiKey(providerId: String, key: String) {
        sharedPreferences.edit().putString("api_key_$providerId", key).apply()
    }

    fun getApiKey(providerId: String): String? {
        return sharedPreferences.getString("api_key_$providerId", null)
    }

    fun deleteApiKey(providerId: String) {
        sharedPreferences.edit().remove("api_key_$providerId").apply()
    }

    fun clearAll() {
        sharedPreferences.edit().clear().apply()
    }
}
