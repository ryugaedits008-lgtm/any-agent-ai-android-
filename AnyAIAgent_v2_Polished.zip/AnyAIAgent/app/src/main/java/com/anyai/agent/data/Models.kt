package com.anyai.agent.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "api_configs")
data class ApiConfig(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val providerName: String,
    val endpointUrl: String,
    val apiKey: String,
    val modelName: String,
    val isActive: Boolean = false
)

@Entity(tableName = "task_logs")
data class TaskLog(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val timestamp: Long = System.currentTimeMillis(),
    val message: String,
    val type: LogType = LogType.INFO
)

enum class LogType {
    INFO, ACTION, ERROR, AI_RESPONSE, USER
}
