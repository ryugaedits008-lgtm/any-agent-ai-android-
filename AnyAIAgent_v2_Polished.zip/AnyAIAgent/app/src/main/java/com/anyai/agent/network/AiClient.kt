package com.anyai.agent.network

import com.google.gson.Gson
import com.google.gson.annotations.SerializedName
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.Body
import retrofit2.http.Header
import retrofit2.http.POST
import retrofit2.http.Url
import java.util.concurrent.TimeUnit

// ---------- Request Models ----------

data class ChatRequest(
    val model: String,
    val messages: List<Message>,
    val tools: List<Tool>? = null,
    @SerializedName("tool_choice") val toolChoice: String? = "auto",
    @SerializedName("max_tokens") val maxTokens: Int = 1000
)

data class Message(
    val role: String,         // "system" | "user" | "assistant" | "tool"
    val content: String?,
    @SerializedName("tool_calls") val toolCalls: List<ToolCall>? = null,
    @SerializedName("tool_call_id") val toolCallId: String? = null,
    val name: String? = null
)

data class Tool(
    val type: String = "function",
    val function: FunctionDef
)

data class FunctionDef(
    val name: String,
    val description: String,
    val parameters: Map<String, Any>
)

data class ToolCall(
    val id: String,
    val type: String,
    val function: FunctionCallData
)

data class FunctionCallData(
    val name: String,
    val arguments: String   // JSON string
)

// ---------- Response Models ----------

data class ChatResponse(
    val choices: List<Choice>?,
    val error: ApiError? = null
)

data class Choice(
    val message: Message,
    @SerializedName("finish_reason") val finishReason: String?
)

data class ApiError(
    val message: String,
    val type: String?
)

// ---------- Retrofit Interface ----------

interface AiService {
    @POST
    suspend fun getCompletion(
        @Url url: String,
        @Header("Authorization") auth: String,
        @Body request: ChatRequest
    ): ChatResponse
}

// ---------- Client Builder ----------

object AiClient {
    private val gson = Gson()

    fun create(baseUrl: String): AiService {
        val logging = HttpLoggingInterceptor().apply {
            level = HttpLoggingInterceptor.Level.BODY
        }
        val client = OkHttpClient.Builder()
            .addInterceptor(logging)
            .connectTimeout(30, TimeUnit.SECONDS)
            .readTimeout(60, TimeUnit.SECONDS)
            .writeTimeout(30, TimeUnit.SECONDS)
            .build()

        val safeBaseUrl = if (baseUrl.endsWith("/")) baseUrl else "$baseUrl/"

        val retrofit = Retrofit.Builder()
            .baseUrl(safeBaseUrl)
            .client(client)
            .addConverterFactory(GsonConverterFactory.create())
            .build()

        return retrofit.create(AiService::class.java)
    }

    // The tools we expose to AI
    fun getAgentTools(): List<Tool> = listOf(
        Tool(function = FunctionDef(
            name = "tap",
            description = "Tap on screen at given coordinates",
            parameters = mapOf(
                "type" to "object",
                "properties" to mapOf(
                    "x" to mapOf("type" to "integer", "description" to "X coordinate"),
                    "y" to mapOf("type" to "integer", "description" to "Y coordinate")
                ),
                "required" to listOf("x", "y")
            )
        )),
        Tool(function = FunctionDef(
            name = "tap_element",
            description = "Tap a UI element by its text or resource ID",
            parameters = mapOf(
                "type" to "object",
                "properties" to mapOf(
                    "text" to mapOf("type" to "string", "description" to "Visible text of the element"),
                    "resource_id" to mapOf("type" to "string", "description" to "Resource ID of the element")
                )
            )
        )),
        Tool(function = FunctionDef(
            name = "type_text",
            description = "Type text into the currently focused input field",
            parameters = mapOf(
                "type" to "object",
                "properties" to mapOf(
                    "text" to mapOf("type" to "string", "description" to "Text to type")
                ),
                "required" to listOf("text")
            )
        )),
        Tool(function = FunctionDef(
            name = "scroll",
            description = "Scroll the screen in a direction",
            parameters = mapOf(
                "type" to "object",
                "properties" to mapOf(
                    "direction" to mapOf(
                        "type" to "string",
                        "enum" to listOf("up", "down", "left", "right")
                    ),
                    "amount" to mapOf("type" to "integer", "description" to "Scroll distance in pixels, default 500")
                ),
                "required" to listOf("direction")
            )
        )),
        Tool(function = FunctionDef(
            name = "press_key",
            description = "Press a system key (BACK, HOME, RECENTS, ENTER)",
            parameters = mapOf(
                "type" to "object",
                "properties" to mapOf(
                    "key" to mapOf(
                        "type" to "string",
                        "enum" to listOf("BACK", "HOME", "RECENTS", "ENTER", "DELETE")
                    )
                ),
                "required" to listOf("key")
            )
        )),
        Tool(function = FunctionDef(
            name = "read_screen",
            description = "Read the current screen UI tree as structured text. Call this to understand what is on screen before acting.",
            parameters = mapOf(
                "type" to "object",
                "properties" to emptyMap<String, Any>()
            )
        )),
        Tool(function = FunctionDef(
            name = "open_app",
            description = "Open an installed app by package name",
            parameters = mapOf(
                "type" to "object",
                "properties" to mapOf(
                    "package_name" to mapOf("type" to "string", "description" to "Android package name e.g. com.whatsapp")
                ),
                "required" to listOf("package_name")
            )
        )),
        Tool(function = FunctionDef(
            name = "wait",
            description = "Wait for a given number of milliseconds before the next action",
            parameters = mapOf(
                "type" to "object",
                "properties" to mapOf(
                    "ms" to mapOf("type" to "integer", "description" to "Milliseconds to wait, max 5000")
                ),
                "required" to listOf("ms")
            )
        )),
        Tool(function = FunctionDef(
            name = "run_shell",
            description = "Run a shell command (ROOT ONLY). Only available on rooted devices.",
            parameters = mapOf(
                "type" to "object",
                "properties" to mapOf(
                    "command" to mapOf("type" to "string", "description" to "Shell command to run")
                ),
                "required" to listOf("command")
            )
        )),
        Tool(function = FunctionDef(
            name = "task_complete",
            description = "Call this when the task is fully completed to signal done.",
            parameters = mapOf(
                "type" to "object",
                "properties" to mapOf(
                    "summary" to mapOf("type" to "string", "description" to "Brief summary of what was accomplished")
                ),
                "required" to listOf("summary")
            )
        ))
    )

    fun parseArguments(jsonStr: String): Map<String, Any> {
        return try {
            @Suppress("UNCHECKED_CAST")
            gson.fromJson(jsonStr, Map::class.java) as Map<String, Any>
        } catch (e: Exception) {
            emptyMap()
        }
    }
}
