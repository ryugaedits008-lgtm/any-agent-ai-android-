package com.anyai.agent.engine

import android.content.Context
import android.content.Intent
import com.anyai.agent.service.AnyAccessibilityService
import com.topjohnwu.superuser.Shell
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

class ActionEngine(private val context: Context) {

    fun isRooted(): Boolean {
        return try {
            Shell.getShell().isRoot
        } catch (e: Exception) {
            false
        }
    }

    suspend fun executeAction(action: String, params: Map<String, Any>): String {
        val service = AnyAccessibilityService.getInstance()

        return when (action) {

            "read_screen" -> {
                service?.getUiTreeAsText() ?: "Error: Accessibility Service not running. Please enable it in Settings."
            }

            "tap" -> {
                val x = (params["x"] as? Number)?.toInt() ?: return "Error: missing x"
                val y = (params["y"] as? Number)?.toInt() ?: return "Error: missing y"
                service?.tap(x, y) ?: return "Error: Accessibility Service not running"
                "Tapped at ($x, $y)"
            }

            "tap_element" -> {
                val text = params["text"] as? String
                val resId = params["resource_id"] as? String
                when {
                    service == null -> "Error: Accessibility Service not running"
                    !text.isNullOrEmpty() -> {
                        if (service.tapByText(text)) "Tapped element with text: \"$text\""
                        else "Error: Element with text \"$text\" not found on screen"
                    }
                    !resId.isNullOrEmpty() -> {
                        if (service.tapByResourceId(resId)) "Tapped element with ID: $resId"
                        else "Error: Element with ID $resId not found"
                    }
                    else -> "Error: provide text or resource_id"
                }
            }

            "type_text" -> {
                val text = params["text"] as? String ?: return "Error: missing text"
                service ?: return "Error: Accessibility Service not running"
                if (service.typeText(text)) "Typed: \"$text\""
                else "Error: No input field focused. Try tapping the field first."
            }

            "scroll" -> {
                val direction = params["direction"] as? String ?: "down"
                val amount = (params["amount"] as? Number)?.toInt() ?: 500
                service?.scroll(direction, amount) ?: return "Error: Accessibility Service not running"
                "Scrolled $direction by $amount px"
            }

            "press_key" -> {
                val key = params["key"] as? String ?: return "Error: missing key"
                service?.pressKey(key) ?: return "Error: Accessibility Service not running"
                "Pressed key: $key"
            }

            "open_app" -> withContext(Dispatchers.Main) {
                val pkg = params["package_name"] as? String ?: return@withContext "Error: missing package_name"
                val intent = context.packageManager.getLaunchIntentForPackage(pkg)
                if (intent != null) {
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    context.startActivity(intent)
                    "Opened app: $pkg"
                } else {
                    "Error: App $pkg not installed"
                }
            }

            "wait" -> {
                val ms = ((params["ms"] as? Number)?.toLong() ?: 1000L).coerceAtMost(5000L)
                delay(ms)
                "Waited ${ms}ms"
            }

            "run_shell" -> {
                if (!isRooted()) return "Error: Root access not available on this device"
                val cmd = params["command"] as? String ?: return "Error: missing command"
                val result = Shell.cmd(cmd).exec()
                val output = result.out.joinToString("\n")
                val err = result.err.joinToString("\n")
                if (result.isSuccess) "Shell output:\n$output"
                else "Shell error:\n$err"
            }

            "task_complete" -> {
                val summary = params["summary"] as? String ?: "Task completed"
                "DONE: $summary"
            }

            else -> "Error: Unknown action '$action'"
        }
    }
}
