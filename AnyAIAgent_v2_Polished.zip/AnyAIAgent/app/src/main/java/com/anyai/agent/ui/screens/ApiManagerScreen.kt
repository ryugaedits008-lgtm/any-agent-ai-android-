package com.anyai.agent.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.anyai.agent.data.ApiConfig
import com.anyai.agent.ui.theme.AnyAIColors
import com.anyai.agent.ui.viewmodel.ApiViewModel

private data class ProviderPreset(val name: String, val url: String, val model: String, val emoji: String, val isFree: Boolean)

private val PRESETS = listOf(
    ProviderPreset("Groq",      "https://api.groq.com/openai/v1",                                   "llama3-70b-8192",       "⚡", true),
    ProviderPreset("Gemini",    "https://generativelanguage.googleapis.com/v1beta/openai",           "gemini-1.5-flash",      "✨", true),
    ProviderPreset("Mistral",   "https://api.mistral.ai/v1",                                         "mistral-large-latest",  "🌊", true),
    ProviderPreset("OpenAI",    "https://api.openai.com/v1",                                         "gpt-4o",                "🤖", false),
    ProviderPreset("Anthropic", "https://api.anthropic.com/v1",                                      "claude-sonnet-4-5",     "🧠", false),
    ProviderPreset("Ollama",    "http://localhost:11434/v1",                                          "llama3",                "🏠", true),
    ProviderPreset("Custom",    "",                                                                   "",                      "⚙️", false),
)

@Composable
fun ApiManagerScreen(vm: ApiViewModel = viewModel()) {
    val configs by vm.allConfigs.collectAsState(initial = emptyList())
    var showAddDialog by remember { mutableStateOf(false) }

    Box(modifier = Modifier.fillMaxSize().background(AnyAIColors.Background)) {
        Column(modifier = Modifier.fillMaxSize().padding(horizontal = 20.dp)) {

            // Header
            Column(modifier = Modifier.padding(top = 20.dp, bottom = 16.dp)) {
                Text("API Keys", fontSize = 26.sp, fontWeight = FontWeight.Black, color = AnyAIColors.TextPrimary)
                Text("AES-256 encrypted · stays on device", fontSize = 12.sp, color = AnyAIColors.TextMuted)
            }

            if (configs.isEmpty()) {
                EmptyApiState(onAdd = { showAddDialog = true })
            } else {
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    contentPadding = PaddingValues(bottom = 100.dp)
                ) {
                    items(configs, key = { it.id }) { config ->
                        ApiCard(config = config, onSetActive = { vm.setActive(config) }, onDelete = { vm.deleteConfig(config) })
                    }
                }
            }
        }

        // FAB
        FloatingActionButton(
            onClick = { showAddDialog = true },
            modifier = Modifier.align(Alignment.BottomEnd).padding(24.dp),
            containerColor = AnyAIColors.Neon,
            shape = RoundedCornerShape(16.dp)
        ) {
            Icon(Icons.Default.Add, contentDescription = "Add", tint = Color.White)
        }
    }

    if (showAddDialog) {
        AddApiDialog(onDismiss = { showAddDialog = false }, onAdd = { name, url, key, model ->
            vm.addConfig(name, url, key, model)
            showAddDialog = false
        })
    }
}

@Composable
fun ApiCard(config: ApiConfig, onSetActive: () -> Unit, onDelete: () -> Unit) {
    var confirmDelete by remember { mutableStateOf(false) }
    val preset = PRESETS.find { it.name == config.providerName }
    val isActive = config.isActive

    Surface(
        shape = RoundedCornerShape(16.dp),
        color = if (isActive) AnyAIColors.Neon.copy(alpha = 0.08f) else AnyAIColors.SurfaceCard,
        modifier = Modifier
            .fillMaxWidth()
            .border(
                width = 1.dp,
                color = if (isActive) AnyAIColors.Neon.copy(alpha = 0.4f) else AnyAIColors.Border,
                shape = RoundedCornerShape(16.dp)
            )
    ) {
        Row(modifier = Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {

            // Emoji avatar
            Box(
                modifier = Modifier.size(44.dp).clip(RoundedCornerShape(12.dp))
                    .background(if (isActive) AnyAIColors.Neon.copy(alpha = 0.15f) else AnyAIColors.SurfaceBright),
                contentAlignment = Alignment.Center
            ) {
                Text(preset?.emoji ?: "⚙️", fontSize = 20.sp)
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(config.providerName, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, color = AnyAIColors.TextPrimary)
                    if (isActive) {
                        Surface(color = AnyAIColors.GreenOk.copy(alpha = 0.15f), shape = RoundedCornerShape(4.dp)) {
                            Text("ACTIVE", modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp, color = AnyAIColors.GreenOk)
                        }
                    }
                }
                Text(config.modelName, fontSize = 12.sp, color = AnyAIColors.TextMuted)
            }

            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                IconButton(onClick = { confirmDelete = true }, modifier = Modifier.size(36.dp)) {
                    Icon(Icons.Default.Delete, contentDescription = "Delete", tint = AnyAIColors.TextMuted, modifier = Modifier.size(16.dp))
                }
                Switch(
                    checked = isActive,
                    onCheckedChange = { if (!isActive) onSetActive() },
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = Color.White,
                        checkedTrackColor = AnyAIColors.Neon,
                        uncheckedThumbColor = AnyAIColors.TextMuted,
                        uncheckedTrackColor = AnyAIColors.SurfaceBright
                    )
                )
            }
        }
    }

    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            containerColor = AnyAIColors.SurfaceCard,
            title = { Text("Delete ${config.providerName}?", color = AnyAIColors.TextPrimary) },
            text = { Text("API key will be permanently deleted.", color = AnyAIColors.TextSecondary) },
            confirmButton = {
                TextButton(onClick = { onDelete(); confirmDelete = false }) {
                    Text("Delete", color = AnyAIColors.RedError, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("Cancel", color = AnyAIColors.TextSecondary) } }
        )
    }
}

@Composable
fun EmptyApiState(onAdd: () -> Unit) {
    Column(
        modifier = Modifier.fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text("🔑", fontSize = 48.sp)
        Spacer(modifier = Modifier.height(16.dp))
        Text("No APIs yet", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = AnyAIColors.TextPrimary)
        Spacer(modifier = Modifier.height(8.dp))
        Text("Add your first API key to get started", fontSize = 13.sp, color = AnyAIColors.TextMuted)
        Spacer(modifier = Modifier.height(6.dp))
        Surface(color = AnyAIColors.GreenOk.copy(alpha = 0.1f), shape = RoundedCornerShape(8.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, AnyAIColors.GreenOk.copy(alpha = 0.3f))) {
            Text("⚡ Groq is FREE and fastest — start there!",
                modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
                fontSize = 12.sp, color = AnyAIColors.GreenOk)
        }
        Spacer(modifier = Modifier.height(24.dp))
        Button(onClick = onAdd, shape = RoundedCornerShape(12.dp), colors = ButtonDefaults.buttonColors(containerColor = AnyAIColors.Neon)) {
            Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text("Add API Key", fontWeight = FontWeight.Bold)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddApiDialog(onDismiss: () -> Unit, onAdd: (String, String, String, String) -> Unit) {
    var selected by remember { mutableStateOf(PRESETS[0]) }
    var providerName by remember { mutableStateOf(PRESETS[0].name) }
    var endpointUrl  by remember { mutableStateOf(PRESETS[0].url) }
    var modelName    by remember { mutableStateOf(PRESETS[0].model) }
    var apiKey       by remember { mutableStateOf("") }
    var showKey      by remember { mutableStateOf(false) }
    var expanded     by remember { mutableStateOf(false) }

    val isValid = providerName.isNotBlank() && endpointUrl.isNotBlank() && apiKey.isNotBlank() && modelName.isNotBlank()

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = AnyAIColors.SurfaceCard,
        shape = RoundedCornerShape(20.dp),
        title = { Text("Add Provider", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = AnyAIColors.TextPrimary) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {

                // Preset chips
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Quick Select", fontSize = 11.sp, color = AnyAIColors.TextMuted, letterSpacing = 0.8.sp, fontWeight = FontWeight.Medium)
                    PRESETS.chunked(4).forEach { row ->
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            row.forEach { preset ->
                                val isSelected = selected == preset
                                Surface(
                                    onClick = {
                                        selected = preset
                                        providerName = preset.name
                                        endpointUrl = preset.url
                                        modelName = preset.model
                                    },
                                    shape = RoundedCornerShape(8.dp),
                                    color = if (isSelected) AnyAIColors.Neon.copy(alpha = 0.15f) else AnyAIColors.SurfaceBright,
                                    border = androidx.compose.foundation.BorderStroke(
                                        1.dp, if (isSelected) AnyAIColors.Neon.copy(alpha = 0.5f) else AnyAIColors.Border
                                    )
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                                    ) {
                                        Text(preset.emoji, fontSize = 12.sp)
                                        Text(preset.name, fontSize = 11.sp, color = if (isSelected) AnyAIColors.Neon else AnyAIColors.TextSecondary, fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal)
                                        if (preset.isFree) {
                                            Text("FREE", fontSize = 8.sp, color = AnyAIColors.GreenOk, fontWeight = FontWeight.Bold, letterSpacing = 0.5.sp)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                Divider(color = AnyAIColors.Border)

                // Input fields
                listOf(
                    Triple("Provider Name", providerName) { v: String -> providerName = v },
                    Triple("Endpoint URL", endpointUrl) { v: String -> endpointUrl = v },
                    Triple("Model Name", modelName) { v: String -> modelName = v },
                ).forEach { (label, value, onChange) ->
                    OutlinedTextField(
                        value = value,
                        onValueChange = onChange,
                        label = { Text(label, fontSize = 12.sp) },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        shape = RoundedCornerShape(10.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = AnyAIColors.Neon,
                            unfocusedBorderColor = AnyAIColors.Border,
                            focusedContainerColor = AnyAIColors.SurfaceBright,
                            unfocusedContainerColor = AnyAIColors.SurfaceBright,
                            focusedTextColor = AnyAIColors.TextPrimary,
                            unfocusedTextColor = AnyAIColors.TextPrimary,
                            focusedLabelColor = AnyAIColors.Neon,
                            unfocusedLabelColor = AnyAIColors.TextMuted,
                        )
                    )
                }

                OutlinedTextField(
                    value = apiKey,
                    onValueChange = { apiKey = it },
                    label = { Text("API Key", fontSize = 12.sp) },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    shape = RoundedCornerShape(10.dp),
                    visualTransformation = if (showKey) VisualTransformation.None else PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                    trailingIcon = {
                        TextButton(onClick = { showKey = !showKey }, contentPadding = PaddingValues(horizontal = 8.dp)) {
                            Text(if (showKey) "Hide" else "Show", fontSize = 11.sp, color = AnyAIColors.Neon)
                        }
                    },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = AnyAIColors.Neon,
                        unfocusedBorderColor = AnyAIColors.Border,
                        focusedContainerColor = AnyAIColors.SurfaceBright,
                        unfocusedContainerColor = AnyAIColors.SurfaceBright,
                        focusedTextColor = AnyAIColors.TextPrimary,
                        unfocusedTextColor = AnyAIColors.TextPrimary,
                        focusedLabelColor = AnyAIColors.Neon,
                        unfocusedLabelColor = AnyAIColors.TextMuted,
                    )
                )

                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    Box(modifier = Modifier.size(6.dp).clip(CircleShape).background(AnyAIColors.GreenOk))
                    Text("Encrypted & stored only on your device", fontSize = 11.sp, color = AnyAIColors.GreenOk)
                }
            }
        },
        confirmButton = {
            Button(
                onClick = { if (isValid) onAdd(providerName, endpointUrl, apiKey, modelName) },
                enabled = isValid,
                shape = RoundedCornerShape(10.dp),
                colors = ButtonDefaults.buttonColors(containerColor = AnyAIColors.Neon, disabledContainerColor = AnyAIColors.SurfaceBright)
            ) { Text("Add", fontWeight = FontWeight.Bold) }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel", color = AnyAIColors.TextSecondary) }
        }
    )
}
