# AnyAI Agent — Setup Guide

Privacy-first Android AI Agent. Bring your own API key, control your phone with AI.

## Quick Start

### 1. Open in Android Studio
- File → Open → select the `AnyAIAgent` folder
- Wait for Gradle sync to complete

### 2. Build & Run
- Connect Android device (API 26+) or start emulator
- Click ▶ Run

### 3. First Launch
1. Go to **APIs tab** → tap `+` → select a provider (Groq is FREE!)
2. Paste your API key → tap Add → toggle it **Active**
3. Go to **Perms tab** → tap **Grant** next to Accessibility Service
4. In Android Settings: find **AnyAI Agent** → enable it
5. Come back to **Agent tab** → type a task → tap Send ▶

## Getting Free API Keys

| Provider | Free? | Speed | Get Key |
|----------|-------|-------|---------|
| **Groq** | ✅ Very generous | ⚡ Fastest | console.groq.com |
| Gemini | ✅ Free tier | Fast | aistudio.google.com |
| Mistral | ✅ Free tier | Good | console.mistral.ai |
| OpenAI | ❌ Paid | Good | platform.openai.com |
| Anthropic | ❌ Paid | Best reasoning | console.anthropic.com |
| Ollama | ✅ Local/Free | Depends | ollama.ai |

**Recommended for testing: Groq with `llama3-70b-8192`**

## Example Tasks
- "Open WhatsApp and send 'Running late' to Rahul"  
- "Open Settings and enable Dark Mode"
- "Take a screenshot and describe what's on screen"
- "Open Chrome and search for today's weather in Mumbai"
- "Set an alarm for 7 AM tomorrow"

## Rooted vs Non-Rooted

| Feature | Non-Rooted | Rooted |
|---------|-----------|--------|
| UI reading | ✅ | ✅ |
| Tap/type/scroll | ✅ | ✅ |
| Open apps | ✅ | ✅ |
| Shell commands | ❌ | ✅ |
| Silent installs | ❌ | ✅ |
| System settings | Limited | ✅ |

## Privacy
- ✅ No login, no account
- ✅ API keys encrypted with AES-256
- ✅ Zero telemetry or analytics
- ✅ All data stays on device
- ✅ Internet only to your chosen AI provider

## Architecture

```
User Task
    ↓
AgentViewModel (coordinates everything)
    ↓
AiClient (calls your API with tool definitions)
    ↓
AI decides: "tap(150, 300)" or "type_text('hello')"
    ↓
ActionEngine (executes the action)
    ↓
AnyAccessibilityService (reads/controls the screen)
    ↓
Result fed back to AI → next step
```
